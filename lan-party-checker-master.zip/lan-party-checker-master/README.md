<h1 align="center">
  OOP Lan Party Checker  
</h1>

OOP Lan Party Checker is a script designed to automate the homework testing. It's an open-source project build by teaching assistants for students of Faculty of Automatic Control & Systems Engineering - PUB. Its purpose is to make the grading systems more transparent and easier for both students & teaching assistants.


## Running the Checker
To verify that the checker is working on your computer follow the next steps:
  - download this repo
  - open a terminal in the root folder of the downloaded repo
  - type the following command: ```./checker.sh```
    - if you get a permission error type the following command: ```chmod +x checker.sh```
